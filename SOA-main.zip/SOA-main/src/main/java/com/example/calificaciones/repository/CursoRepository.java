package com.example.calificaciones.repository; // Mantenemos el paquete

import com.example.calificaciones.model.curso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CursoRepository extends JpaRepository<curso, Long> {
    // Para buscar por nombre o fecha de inicio antes de editar [cite: 39]
    List<curso> findByNombre(String nombre);
    List<curso> findByFechaInicio(java.time.LocalDate fechaInicio);
}