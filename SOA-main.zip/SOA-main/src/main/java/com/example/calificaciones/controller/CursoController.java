package com.example.calificaciones.controller;

import com.example.calificaciones.model.curso;
import com.example.calificaciones.repository.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/cursos") // Nuevo endpoint [cite: 40]
public class CursoController {

    @Autowired
    private CursoRepository cursoRepository;

    // 1. Registrar Curso (POST) [cite: 37]
    @PostMapping
    public ResponseEntity<curso> registrarCurso(@RequestBody curso curso) {
        curso nuevoCurso = cursoRepository.save(curso);
        return new ResponseEntity<>(nuevoCurso, HttpStatus.CREATED);
    }

    // Método de búsqueda (necesario antes de editar) [cite: 39]
    @GetMapping("/buscar")
    public ResponseEntity<List<curso>> buscarCursos(@RequestParam(required = false) String nombre,
                                                     @RequestParam(required = false) String fecha) {
        if (nombre != null) {
            return new ResponseEntity<>(cursoRepository.findByNombre(nombre), HttpStatus.OK);
        }
        if (fecha != null) {
            LocalDate fechaInicio = LocalDate.parse(fecha);
            return new ResponseEntity<>(cursoRepository.findByFechaInicio(fechaInicio), HttpStatus.OK);
        }
        return new ResponseEntity<>(cursoRepository.findAll(), HttpStatus.OK);
    }

    // 2. Editar Curso (PUT) [cite: 38]
    @PutMapping("/{id}")
    public ResponseEntity<curso> editarCurso(@PathVariable Long id, @RequestBody curso cursoDetalles) {
        Optional<curso> cursoExistente = cursoRepository.findById(id);

        if (cursoExistente.isPresent()) {
            curso curso = cursoExistente.get();
            // Actualizar campos requeridos
            curso.setNombre(cursoDetalles.getNombre());
            curso.setDescripcion(cursoDetalles.getDescripcion());
            curso.setCreditos(cursoDetalles.getCreditos());
            curso.setFechaInicio(cursoDetalles.getFechaInicio());
            
            curso cursoActualizado = cursoRepository.save(curso);
            return new ResponseEntity<>(cursoActualizado, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}