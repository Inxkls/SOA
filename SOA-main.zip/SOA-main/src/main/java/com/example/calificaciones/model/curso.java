package com.example.calificaciones.model; // Usaremos el mismo paquete por simplicidad

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDate;

@Entity
public class curso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre; // Usado para buscar
    private String descripcion;
    private Integer creditos;
    private LocalDate fechaInicio; // Usado para buscar/editar

    // Getters, Setters y Constructores (puedes usar Lombok si lo prefieres)

    // Constructor vacío
    public curso() {}

    // Constructor completo
    public curso(String nombre, String descripcion, Integer creditos, LocalDate fechaInicio) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.creditos = creditos;
        this.fechaInicio = fechaInicio;
    }

    // --- GETTERS & SETTERS ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public Integer getCreditos() { return creditos; }
    public void setCreditos(Integer creditos) { this.creditos = creditos; }
    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }
}