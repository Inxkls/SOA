package com.example.calificaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalificacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalificacionesApplication.class, args);
	}

}
