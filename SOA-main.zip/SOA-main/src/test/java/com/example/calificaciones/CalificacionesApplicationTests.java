package com.example.calificaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalificacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
