from spyne import Application, rpc, ServiceBase, Integer, Unicode, Array, ComplexModel
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
import logging
import database
import traceback
import sys
from datetime import date # Aunque no se usa, lo dejamos por si acaso

# ----------------- CONFIGURACIÓN DE LOGGING -----------------
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('soap_server.log', encoding='utf-8')
    ],
    force=True
)
logger = logging.getLogger(__name__)

# Inicializar base de datos al inicio
logger.info("=== INICIALIZANDO BASE DE DATOS ===")
database.init_db()
logger.info("=== BASE DE DATOS INICIALIZADA ===")

# ----------------- ENTIDAD REQUERIDA (ALUMNO) -----------------
class Alumno(ComplexModel):
    __namespace__ = 'matriculas_service' # Nuevo namespace
    id = Integer
    matricula = Unicode 
    nombre = Unicode
    carrera = Unicode

# ----------------- SERVICIO SOAP (MATRÍCULAS) -----------------
class AlumnoService(ServiceBase):
    
    # 1. Registrar un alumno (SOAP)
    @rpc(Unicode, Unicode, Unicode, _returns=Unicode)
    def RegistrarAlumno(self, matricula, nombre, carrera):
        logger.info(f"=== INICIANDO RegistrarAlumno para {matricula} ===")
        conn = database.get_db_connection()
        if not conn or not conn.is_connected():
            return "Error: No se pudo conectar a BD"
        
        try:
            cursor = conn.cursor()
            query = "INSERT INTO alumno (matricula, nombre, carrera) VALUES (%s, %s, %s)"
            cursor.execute(query, (matricula, nombre, carrera))
            conn.commit()
            return f"Alumno {nombre} registrado con matrícula {matricula}."
            
        except Exception as e:
            logger.error(f"Error BD al registrar: {e}")
            return f"Error: {str(e)}"
        finally:
            if conn and conn.is_connected(): conn.close()


    # 2. Consultar alumnos por matrícula (necesario para la eliminación)
    @rpc(Unicode, _returns=Array(Alumno))
    def ConsultarAlumnosPorMatricula(self, matricula):
        logger.info(f"=== INICIANDO ConsultarAlumnosPorMatricula ===")
        conn = database.get_db_connection()
        if not conn or not conn.is_connected(): return []
        
        try:
            cursor = conn.cursor(dictionary=True)
            query = "SELECT id, matricula, nombre, carrera FROM alumno WHERE matricula = %s"
            cursor.execute(query, (matricula,))
            rows = cursor.fetchall()
            
            alumnos_list = []
            for row in rows:
                alumnos_list.append(Alumno(id=row['id'], matricula=row['matricula'], 
                                           nombre=row['nombre'], carrera=row['carrera']))
            return alumnos_list
            
        except Exception as e:
            logger.error(f"Error al consultar: {e}")
            return []
        finally:
            if conn and conn.is_connected(): conn.close()


    # 3. Eliminar una lista de alumnos (Función requerida por el examen)
    @rpc(Array(Unicode), _returns=Unicode)
    def EliminarAlumnosEnLote(self, matriculas):
        logger.info(f"=== INICIANDO Eliminación en Lote para {len(matriculas)} matrículas ===")
        conn = database.get_db_connection()
        if not conn or not conn.is_connected(): return "Error: No se pudo conectar a BD"
        
        eliminados = 0
        errores = 0
        try:
            cursor = conn.cursor()
            for matricula in matriculas:
                # El examen pide CONSULTAR primero, luego ELIMINAR
                
                # 1. Consulta (Verificación simple, para cumplir el requisito)
                consulta_existencia = self.ConsultarAlumnosPorMatricula(matricula)
                if not consulta_existencia:
                    logger.warning(f"Matrícula {matricula} no encontrada.")
                    errores += 1
                    continue

                # 2. Eliminar
                delete_query = "DELETE FROM alumno WHERE matricula = %s"
                cursor.execute(delete_query, (matricula,))
                if cursor.rowcount > 0:
                    eliminados += 1
                    logger.info(f"Matrícula {matricula} eliminada.")
                else:
                    errores += 1 # Si no elimina a pesar de la consulta, cuenta como error
                    
            conn.commit()
            return f"Proceso completado. {eliminados} alumnos eliminados, {errores} fallidos/no encontrados."
            
        except Exception as e:
            conn.rollback()
            logger.error(f"Error en Eliminación en Lote: {e}")
            return f"Error en la BD durante la eliminación: {str(e)}"
        finally:
            if conn and conn.is_connected(): conn.close()

# ----------------- CONFIGURACIÓN DE LA APLICACIÓN -----------------
application = Application([AlumnoService], 'spyne.examples.matriculas.soap',
                              in_protocol=Soap11(validator=None),
                              out_protocol=Soap11())

# Wrapper WSGI para capturar errores (modificado para no importar cgi)
def error_handling_wsgi_app(environ, start_response):
    logger.info(f"Solicitud recibida: {environ['REQUEST_METHOD']} {environ['PATH_INFO']}")
    try:
        from spyne.server.wsgi import WsgiApplication
        # Asegúrate de que WsgiApplication use el wrapper que creamos antes
        wsgi_app = WsgiApplication(application) 
        return wsgi_app(environ, start_response)
    except Exception as e:
        logger.error(f"Error WSGI: {type(e).__name__}: {e}")
        logger.error(traceback.format_exc())
        start_response('500 Internal Server Error', [('Content-Type', 'text/plain')])
        return [b'Internal Server Error']

if __name__ == '__main__':
    from wsgiref.simple_server import make_server
    
    print("Iniciando servidor SOAP en http://127.0.0.1:8000", flush=True)
    print("WSDL disponible en http://127.0.0.1:8000/?wsdl", flush=True)
    sys.stdout.flush()
    
    try:
        # Usamos el error_handling_wsgi_app para envolver el servidor
        server = make_server('127.0.0.1', 8000, error_handling_wsgi_app)
        print("Servidor listo. Esperando solicitudes...", flush=True)
        sys.stdout.flush()
        server.serve_forever()
    except Exception as e:
        logger.error(f"Error iniciando servidor: {e}")
        logger.error(traceback.format_exc())