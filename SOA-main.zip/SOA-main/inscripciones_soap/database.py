import mysql.connector
from mysql.connector import Error

# Configuración con la contraseña correcta
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Leones1320', # Usamos la contraseña que encontramos
    'database': 'inscripciones_db' # Usaremos la BD de inscripciones/matriculas
}

def get_db_connection():
    """Establishes a connection to the MySQL database."""
    try:
        # Crea una copia mutable del diccionario para evitar modificar la global
        config = DB_CONFIG.copy()
        connection = mysql.connector.connect(**config)
        return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

def init_db():
    """Initializes the database table for ALUMNO."""
    # Primero intentamos conectar sin especificar base de datos para crearla si no existe
    try:
        conn_base = mysql.connector.connect(host=DB_CONFIG['host'], user=DB_CONFIG['user'], password=DB_CONFIG['password'])
        cursor_base = conn_base.cursor()
        cursor_base.execute(f"CREATE DATABASE IF NOT EXISTS {DB_CONFIG['database']}")
        print(f"Database '{DB_CONFIG['database']}' checked/created.")
        cursor_base.close()
        conn_base.close()
    except Error as e:
        print(f"Error creating database: {e}")

    # Ahora conectamos a la base de datos y creamos la tabla ALUMNO
    connection = get_db_connection()
    if connection and connection.is_connected():
        try:
            cursor = connection.cursor()
            create_table_query = """
            CREATE TABLE IF NOT EXISTS alumno (
                id INT AUTO_INCREMENT PRIMARY KEY,
                matricula VARCHAR(255) NOT NULL,
                nombre VARCHAR(255) NOT NULL,
                carrera VARCHAR(255) NOT NULL
            )
            """
            cursor.execute(create_table_query)
            connection.commit()
            print("Table 'alumno' checked/created successfully.")
        except Error as e:
            print(f"Error creating table: {e}")
        finally:
            if connection.is_connected():
                cursor.close()
                connection.close()

if __name__ == '__main__':
    init_db()